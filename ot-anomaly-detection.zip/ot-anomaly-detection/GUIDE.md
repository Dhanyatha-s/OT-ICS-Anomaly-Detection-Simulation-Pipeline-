# OT/ICS Anomaly Detection — Complete Beginner's Guide
## From Zero to Running Project (Zero Docker/Kafka Experience Needed)

---

## WHAT YOU'RE BUILDING (Plain English)

You're building a system that watches a fake industrial machine (like a power plant sensor),
learns what "normal" looks like, and screams when something suspicious happens.

```
[Fake OT Sensor] → [Kafka Queue] → [Logstash] → [Elasticsearch] → [Kibana Dashboard]
                                                        ↑
                                             [ML Detection Service]
                                                        ↑
                                                  [MLFlow Tracking]
```

---

## BEFORE YOU START — INSTALL THESE (ONE TIME ONLY)

### 1. Install Docker Desktop
- Go to: https://www.docker.com/products/docker-desktop/
- Download for your OS (Windows/Mac/Linux)
- Install it. Open it. Make sure the whale icon appears in your taskbar.
- **Docker is like a box that runs programs without messing up your computer.**
  Everything in this project (Kafka, Elasticsearch, Kibana) runs inside Docker boxes called "containers."

### 2. Install Python 3.11+
- Go to: https://www.python.org/downloads/
- Download Python 3.11 or newer
- During install on Windows: ✅ CHECK "Add Python to PATH"

### 3. Install Python packages
Open a terminal/command prompt inside the project folder and run:
```bash
pip install -r requirements.txt
```
This installs: pymodbus, kafka-python, scikit-learn, tensorflow, mlflow, elasticsearch, etc.

---

## PROJECT FOLDER STRUCTURE

```
ot-anomaly-detection/
├── docker-compose.yml         ← Defines all services (Kafka, ES, Kibana, etc.)
├── requirements.txt           ← Python packages to install
│
├── simulator/
│   ├── modbus_server.py       ← Fake OT device (run this first)
│   └── attack_injector.py     ← Triggers attack simulations
│
├── pipeline/
│   └── kafka_producer.py      ← Reads sensor data, sends to Kafka
│
├── logstash/
│   └── pipeline.conf          ← Logstash config (auto-used by Docker)
│
├── detection/
│   ├── train_model.py         ← Trains the ML anomaly models
│   ├── detect_service.py      ← Live anomaly scoring (runs 24/7)
│   └── models/                ← Saved model files (auto-created after training)
│
└── mlflow_server/             ← MLFlow data storage (auto-created)
```

---

## STEP 1 — START ALL DOCKER SERVICES

This is the most important step. One command starts everything.

Open a terminal in the `ot-anomaly-detection/` folder and run:

```bash
docker-compose up -d
```

**What `-d` means:** "detached mode" — runs in background so your terminal is free.

**What this command does:**
- Downloads images for Kafka, Zookeeper, Elasticsearch, Kibana, Logstash, MLFlow
  (First time takes 5–10 minutes depending on internet speed)
- Starts all 6 services as containers
- They all talk to each other on an internal network called "ot-network"

**To check if everything is running:**
```bash
docker-compose ps
```
You should see all services with status "Up".

**To see logs if something breaks:**
```bash
docker-compose logs elasticsearch    # Check ES logs
docker-compose logs kafka            # Check Kafka logs
docker-compose logs logstash         # Check Logstash logs
```

**Wait 60 seconds** after running `up -d` before the next step.
Elasticsearch especially takes time to fully start.

---

## STEP 2 — VERIFY SERVICES ARE UP

Open these URLs in your browser:

| Service       | URL                     | What you should see              |
|---------------|-------------------------|----------------------------------|
| Kibana        | http://localhost:5601   | Kibana loading screen            |
| Elasticsearch | http://localhost:9200   | JSON with "cluster_name" info    |
| MLFlow        | http://localhost:5000   | MLFlow experiment tracking UI    |

If Kibana shows an error — wait 2 more minutes and refresh. It waits for ES to start.

---

## STEP 3 — START THE FAKE OT DEVICE (MODBUS SERVER)

Open Terminal #1. Navigate to the project folder and run:

```bash
python simulator/modbus_server.py
```

You should see:
```
============================================================
OT Device Simulator (Modbus TCP Server)
Listening on 0.0.0.0:5020
============================================================
[SERVER] OT Device Updater started — writing sensor values every 2s
[SERVER] Temp=74.2°C  Pressure=98.7PSI  Flow=29.1L/min  Valve=1  Vibration=1.45mm/s  ✅ Normal
[SERVER] Temp=75.8°C  Pressure=101.2PSI  Flow=30.5L/min  Valve=1  Vibration=1.52mm/s  ✅ Normal
```

**What just happened:** You started a fake industrial sensor broadcasting readings over Modbus TCP.
This is simulating what a real PLC (Programmable Logic Controller) does in a factory.

**Leave this terminal running.**

---

## STEP 4 — START THE KAFKA PRODUCER

Open Terminal #2. Run:

```bash
python pipeline/kafka_producer.py
```

You should see:
```
============================================================
Kafka Producer — OT Telemetry
Reading from Modbus: localhost:5020
Publishing to Kafka topic: ot-telemetry
============================================================
[MODBUS] Connecting to localhost:5020 (attempt 1/5)...
[MODBUS] ✅ Connected to OT device simulator!
[KAFKA]  Connecting to broker at localhost:9092 (attempt 1/10)...
[KAFKA]  ✅ Connected successfully!
[MSG #1] → Kafka | Temp=74.2°C  Pressure=98.7PSI  Flow=29.1L/min  Valve=OPEN
[MSG #2] → Kafka | Temp=75.8°C  Pressure=101.2PSI  Flow=30.5L/min  Valve=OPEN
```

**What just happened:**
- It connected to the Modbus server (your fake sensor)
- It connected to Kafka (running in Docker)
- Every 2 seconds it reads sensor values and publishes a JSON message to the "ot-telemetry" Kafka topic

**Leave this terminal running.**

---

## STEP 5 — VERIFY DATA IS IN ELASTICSEARCH

After 2-3 minutes of the producer running, check if data reached Elasticsearch.

Open your browser and go to:
```
http://localhost:9200/ot-sensors-*/_count
```

You should see something like:
```json
{"count": 87, "_shards": {...}}
```

The count should keep growing as more data comes in.

**Alternatively from terminal:**
```bash
curl http://localhost:9200/ot-sensors-*/_count
```

**How did data get there?**
kafka_producer → Kafka topic → Logstash reads it → Logstash sends to Elasticsearch
(Logstash is running inside Docker and doing this automatically)

---

## STEP 6 — SET UP KIBANA DASHBOARD

1. Open http://localhost:5601
2. Click "Explore on my own" (skip the welcome screen)
3. Go to Menu → Stack Management → Index Patterns
4. Click "Create index pattern"
5. In the name field type: `ot-sensors-*`
6. Time field: select `@timestamp`
7. Click "Create index pattern"

Now go to Menu → Discover.
You should see your sensor data streaming in as documents!

**Create a basic dashboard:**
1. Menu → Dashboard → Create dashboard
2. Click "Create visualization"
3. Choose "Line" chart
4. X-axis: `@timestamp`
5. Y-axis: Average of `temperature`
6. Save it, add more charts for pressure, anomaly_score, etc.

---

## STEP 7 — COLLECT NORMAL DATA (30–60 MINUTES)

Let the simulator run in normal mode for 30–60 minutes.
This gives the ML model enough "normal" examples to learn from.

You can check how much data you have with:
```bash
curl http://localhost:9200/ot-sensors-*/_count
```

**Aim for at least 1,000 documents** (about 33 minutes at 2-second intervals).

---

## STEP 8 — TRAIN THE ANOMALY DETECTION MODELS

Open Terminal #3. Run:

```bash
python detection/train_model.py
```

You'll see training progress:
```
[DATA] Loading 1842 documents from Elasticsearch...
[PREP] Feature matrix shape: (1842, 5)
[IF] Training Isolation Forest...
[IF] Detected 92 anomalies (5.0% of data)
[IF] ✅ Model saved to ./detection/models/isolation_forest.joblib
[LSTM] Creating sequences of length 10...
[LSTM] Training LSTM Autoencoder...
Epoch 1/50: loss=0.4521  val_loss=0.4398
Epoch 2/50: loss=0.3821  val_loss=0.3715
...
[LSTM] ✅ Model saved to ./detection/models/lstm_autoencoder.keras
```

After training, check your MLFlow dashboard at http://localhost:5000
You'll see experiment runs with metrics logged!

---

## STEP 9 — START LIVE DETECTION SERVICE

Open Terminal #4. Run:

```bash
python detection/detect_service.py
```

You'll see:
```
[RUNNING] Detection service active. Press Ctrl+C to stop.
[10:23:41] Scored 8 new readings | Anomalies this batch: 0 | Total scored: 8
[10:23:51] Scored 5 new readings | Anomalies this batch: 0 | Total scored: 13
```

Now everything is fully running! The service scores every new reading
and writes anomaly_score back to Elasticsearch.

---

## STEP 10 — TRIGGER AN ATTACK AND WATCH IT DETECTED

Open Terminal #5. Run:

```bash
python simulator/attack_injector.py
```

Choose option 1 (SPIKE attack). Watch Terminal #1 (modbus_server) switch to attack readings.
Watch Terminal #4 (detect_service) start alerting:

```
=======================================================
  🔴 CRITICAL ANOMALY DETECTED  (score: 0.923)
  Method: IF+LSTM
  Temp:      134.5°C      ← WAY above normal 65-85°C
  Pressure:  387.2 PSI    ← WAY above normal 80-120 PSI
  Flow:      2.1 L/min    ← WAY below normal 20-40 L/min
  Valve:     CLOSED       ← Should be OPEN
  Vibration: 18.23 mm/s   ← WAY above normal 0.5-3.0 mm/s
=======================================================
```

Now go to Kibana and refresh your dashboard. You'll see the anomaly_score spike on the graph!

---

## TERMINAL SUMMARY (What's Running Where)

```
Terminal 1: python simulator/modbus_server.py      ← The fake sensor (always on)
Terminal 2: python pipeline/kafka_producer.py       ← Reads sensor, feeds Kafka (always on)
Terminal 3: python detection/train_model.py         ← Run once to train
Terminal 4: python detection/detect_service.py      ← Live detection (always on)
Terminal 5: python simulator/attack_injector.py     ← Optional: trigger attacks
```

Docker handles: Kafka, Elasticsearch, Kibana, Logstash, MLFlow (all automatic)

---

## STOPPING EVERYTHING

```bash
# Stop Docker services (data is preserved)
docker-compose stop

# Stop Docker AND delete all data (fresh start)
docker-compose down -v

# Restart later
docker-compose up -d
```

---

## COMMON ERRORS AND FIXES

**"NoBrokersAvailable" in kafka_producer.py**
→ Kafka hasn't finished starting. Wait 60 seconds and retry.
→ Check: `docker-compose ps` — is kafka showing "Up"?

**"ConnectionError" in kafka_producer.py**
→ modbus_server.py is not running. Start it in Terminal 1 first.

**curl returns "connection refused" for port 9200**
→ Elasticsearch is still starting. Wait 1-2 minutes.
→ Check: `docker-compose logs elasticsearch`

**"FileNotFoundError: scaler.joblib" in detect_service.py**
→ You haven't trained yet. Run `train_model.py` first.

**Port already in use error**
→ Something else on your computer is using port 9092/9200/5601.
→ Check with: `netstat -ano | grep 9092` (Windows) or `lsof -i :9092` (Mac/Linux)

**Docker Desktop is not running**
→ Open Docker Desktop application first, wait for whale icon to appear.

---

## WHAT TO TELL AN INTERVIEWER

"I built an end-to-end OT security monitoring pipeline from scratch.
I simulated Modbus TCP telemetry from an industrial sensor,
ingested it through a Kafka → Logstash → Elasticsearch pipeline,
trained Isolation Forest and LSTM Autoencoder models to detect anomalies,
deployed a live scoring service that writes back to Elasticsearch in real time,
and built Kibana dashboards to visualize the detections.
I also simulated three attack patterns — sensor spoofing, replay attacks,
and unauthorized actuator commands — to validate the detection pipeline.
All model experiments were tracked with MLFlow."
