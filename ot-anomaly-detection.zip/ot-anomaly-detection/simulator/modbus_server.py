"""
modbus_server.py
================
WHAT THIS IS:
  A fake industrial sensor / OT device.
  In real factories, machines like PLCs (Programmable Logic Controllers)
  communicate using the Modbus TCP protocol over a network.
  This script pretends to BE one of those machines.

WHAT IT DOES:
  - Starts a Modbus TCP server on port 5020
  - Continuously updates "registers" (memory slots) with realistic
    sensor readings: temperature, pressure, flow rate, valve status
  - Runs in normal mode OR attack mode (controlled by a flag file)

HOW IT LINKS TO EVERYTHING ELSE:
  kafka_producer.py  →  READS from this server every 2 seconds
                     →  Sends the readings to Kafka

HOW TO RUN:
  pip install pymodbus
  python modbus_server.py

  To trigger an attack simulation:
  touch /tmp/inject_attack     (Linux/Mac)
  echo "" > C:\\tmp\\inject_attack  (Windows - create the file manually)
"""

import time
import random
import threading
import os
from pymodbus.server import StartTcpServer
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext

# ── Constants ──────────────────────────────────────────────────────────
HOST = "0.0.0.0"
PORT = 5020

# Modbus register addresses (think of these as variable slots in memory)
# Each register holds a 16-bit integer (0–65535)
# We scale floats: e.g., temperature 72.5°C is stored as 7250 (multiply by 100)
REG_TEMPERATURE  = 0   # °C × 100    Normal: 6500–8500  (65.0–85.0°C)
REG_PRESSURE     = 1   # PSI × 10    Normal: 800–1200   (80.0–120.0 PSI)
REG_FLOW_RATE    = 2   # L/min × 10  Normal: 200–400    (20.0–40.0 L/min)
REG_VALVE_STATUS = 3   # 0=closed, 1=open, 2=partial  Normal: 1
REG_VIBRATION    = 4   # mm/s × 100  Normal: 50–300     (0.5–3.0 mm/s)

ATTACK_FLAG_FILE = "/tmp/inject_attack"  # Touch this file to trigger attack mode


def is_attack_mode():
    """Check if the attack flag file exists."""
    return os.path.exists(ATTACK_FLAG_FILE)


def generate_normal_readings():
    """
    Simulate realistic normal sensor behavior.
    Small random variations around a baseline — what a healthy machine looks like.
    """
    return {
        REG_TEMPERATURE:  int(random.gauss(7500, 150)),   # ~75°C ± noise
        REG_PRESSURE:     int(random.gauss(1000, 30)),    # ~100 PSI ± noise
        REG_FLOW_RATE:    int(random.gauss(300, 20)),     # ~30 L/min ± noise
        REG_VALVE_STATUS: 1,                              # Always open (normal)
        REG_VIBRATION:    int(random.gauss(150, 25)),     # ~1.5 mm/s ± noise
    }


def generate_attack_readings(attack_type="spike"):
    """
    Simulate different OT attack patterns.

    SPIKE:       Sudden extreme value — like a sensor being spoofed
    REPLAY:      Same value repeated — attacker replaying captured packets
    VALVE_FLIP:  Rapid valve open/close — unauthorized actuator command
    FREEZE:      Value never changes — attacker injecting fake "all is well" data
    """
    if attack_type == "spike":
        print("[ATTACK] Injecting SPIKE attack — temperature/pressure out of range")
        return {
            REG_TEMPERATURE:  random.randint(12000, 15000),  # 120–150°C (danger zone)
            REG_PRESSURE:     random.randint(3000, 5000),    # 300–500 PSI (way too high)
            REG_FLOW_RATE:    random.randint(0, 50),         # Near zero (blocked)
            REG_VALVE_STATUS: 0,                             # Forced closed
            REG_VIBRATION:    random.randint(1000, 3000),    # Extreme vibration
        }
    elif attack_type == "replay":
        print("[ATTACK] Injecting REPLAY attack — frozen normal-looking values")
        return {
            REG_TEMPERATURE:  7500,   # Suspiciously perfect value
            REG_PRESSURE:     1000,
            REG_FLOW_RATE:    300,
            REG_VALVE_STATUS: 1,
            REG_VIBRATION:    150,
        }
    elif attack_type == "valve_flip":
        print("[ATTACK] Injecting VALVE FLIP — rapid unauthorized valve switching")
        return {
            REG_TEMPERATURE:  int(random.gauss(7500, 50)),
            REG_PRESSURE:     random.randint(500, 2000),     # Pressure swings
            REG_FLOW_RATE:    random.randint(0, 600),        # Flow swings
            REG_VALVE_STATUS: random.choice([0, 2]),         # Rapidly switching
            REG_VIBRATION:    int(random.gauss(150, 50)),
        }
    else:
        return generate_normal_readings()


class OTDeviceUpdater(threading.Thread):
    """
    Background thread that updates the Modbus registers every 2 seconds.
    The Modbus server holds these registers in memory.
    kafka_producer.py reads them by connecting to the server.
    """

    def __init__(self, context):
        super().__init__(daemon=True)
        self.context = context
        self.attack_types = ["spike", "replay", "valve_flip"]
        self.attack_index = 0

    def run(self):
        print("[SERVER] OT Device Updater started — writing sensor values every 2s")
        while True:
            slave = self.context[0]  # Access slave device context

            if is_attack_mode():
                # Cycle through attack types while flag file exists
                attack = self.attack_types[self.attack_index % len(self.attack_types)]
                readings = generate_attack_readings(attack)
                self.attack_index += 1
            else:
                readings = generate_normal_readings()
                if self.attack_index > 0:
                    print("[SERVER] Attack mode ended, back to normal readings")
                    self.attack_index = 0

            # Write all register values into the Modbus datastore
            # FC3 = function code for holding registers (standard Modbus read/write registers)
            values = [readings[i] for i in range(5)]
            slave.setValues(3, 0, values)  # (function_code, start_address, values)

            print(f"[SERVER] Temp={readings[0]/100:.1f}°C  "
                  f"Pressure={readings[1]/10:.1f}PSI  "
                  f"Flow={readings[2]/10:.1f}L/min  "
                  f"Valve={readings[3]}  "
                  f"Vibration={readings[4]/100:.2f}mm/s  "
                  f"{'⚠️ ATTACK' if is_attack_mode() else '✅ Normal'}")

            time.sleep(2)


def main():
    print("=" * 60)
    print("OT Device Simulator (Modbus TCP Server)")
    print(f"Listening on {HOST}:{PORT}")
    print("Connect kafka_producer.py to read these values")
    print(f"Create file '{ATTACK_FLAG_FILE}' to trigger attack mode")
    print("=" * 60)

    # Create the Modbus datastore
    # 10 registers starting from address 0, all initialized to 0
    store = ModbusSlaveContext(
        hr=ModbusSequentialDataBlock(0, [0] * 10)  # Holding registers
    )
    context = ModbusServerContext(slaves=store, single=True)

    # Start the background thread that updates register values
    updater = OTDeviceUpdater(context)
    updater.start()

    # Start the Modbus TCP server (this blocks — runs forever)
    print("[SERVER] Starting Modbus TCP server...")
    StartTcpServer(context=context, address=(HOST, PORT))


if __name__ == "__main__":
    main()
