"""
attack_injector.py
==================
WHAT THIS IS:
  A simple controller script that tells the modbus_server.py
  to switch between normal and attack mode.

WHAT IT DOES:
  - Interactive menu to start/stop different attack scenarios
  - Creates or deletes a flag file that modbus_server.py checks
  - Also logs attack events directly to Elasticsearch so you can
    see them as ground truth labels on your Kibana dashboard

HOW IT LINKS TO EVERYTHING ELSE:
  modbus_server.py  ←  Reads /tmp/inject_attack flag file
  Elasticsearch     ←  Logs attack events for dashboard labeling

HOW TO RUN (in a separate terminal while modbus_server.py is running):
  pip install elasticsearch
  python attack_injector.py
"""

import os
import time
import json
from datetime import datetime, timezone

# Try to import elasticsearch — if not installed, attack logging still works
try:
    from elasticsearch import Elasticsearch
    ES_AVAILABLE = True
except ImportError:
    ES_AVAILABLE = False
    print("[WARN] elasticsearch package not installed — ES logging disabled")
    print("       Run: pip install elasticsearch")

ATTACK_FLAG_FILE = "/tmp/inject_attack"
ES_HOST = "http://localhost:9200"
ES_INDEX = "ot-attack-events"


def log_to_elasticsearch(event_type, description, active):
    """Write attack event to Elasticsearch for dashboard labeling."""
    if not ES_AVAILABLE:
        return
    try:
        es = Elasticsearch(ES_HOST)
        doc = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event_type": event_type,
            "description": description,
            "attack_active": active,
            "source": "attack_injector"
        }
        es.index(index=ES_INDEX, document=doc)
        print(f"[ES] Logged attack event: {event_type}")
    except Exception as e:
        print(f"[ES] Could not log to Elasticsearch: {e}")


def start_attack(attack_type="spike"):
    """Activate attack mode by creating the flag file."""
    descriptions = {
        "spike":      "Sensor value spike — spoofed high temperature/pressure readings",
        "replay":     "Replay attack — attacker injecting old captured packet values",
        "valve_flip": "Unauthorized actuator command — rapid valve open/close cycling"
    }
    desc = descriptions.get(attack_type, "Unknown attack")

    with open(ATTACK_FLAG_FILE, "w") as f:
        f.write(attack_type)

    print(f"\n🔴 ATTACK STARTED: {attack_type.upper()}")
    print(f"   {desc}")
    print(f"   Flag file created: {ATTACK_FLAG_FILE}")
    print("   modbus_server.py will now emit anomalous readings")

    log_to_elasticsearch(attack_type, desc, active=True)


def stop_attack():
    """Deactivate attack mode by removing the flag file."""
    if os.path.exists(ATTACK_FLAG_FILE):
        os.remove(ATTACK_FLAG_FILE)
        print("\n✅ ATTACK STOPPED — back to normal readings")
        log_to_elasticsearch("attack_stopped", "Attack simulation ended", active=False)
    else:
        print("\n[INFO] No attack was active")


def run_timed_attack(attack_type, duration_seconds):
    """Run an attack for a fixed duration then auto-stop."""
    start_attack(attack_type)
    print(f"   Auto-stopping in {duration_seconds} seconds...")
    time.sleep(duration_seconds)
    stop_attack()


def main():
    print("=" * 60)
    print("OT Attack Injector")
    print("Controls the attack simulation in modbus_server.py")
    print("=" * 60)

    while True:
        print("\n─── Attack Menu ───────────────────────────────")
        print("  1. Start SPIKE attack      (sensor value spoofing)")
        print("  2. Start REPLAY attack     (frozen packet injection)")
        print("  3. Start VALVE FLIP attack (unauthorized actuator)")
        print("  4. Stop all attacks        (return to normal)")
        print("  5. Timed attack (30 sec)   (auto-stops)")
        print("  6. Status check")
        print("  q. Quit")
        print("───────────────────────────────────────────────")

        choice = input("Enter choice: ").strip().lower()

        if choice == "1":
            start_attack("spike")
        elif choice == "2":
            start_attack("replay")
        elif choice == "3":
            start_attack("valve_flip")
        elif choice == "4":
            stop_attack()
        elif choice == "5":
            print("\nChoose attack type: spike / replay / valve_flip")
            atype = input("Type: ").strip()
            run_timed_attack(atype, 30)
        elif choice == "6":
            if os.path.exists(ATTACK_FLAG_FILE):
                with open(ATTACK_FLAG_FILE) as f:
                    content = f.read().strip()
                print(f"\n🔴 ATTACK ACTIVE: {content}")
            else:
                print("\n✅ No attack active — system in normal state")
        elif choice == "q":
            stop_attack()  # Clean up before exit
            print("Exiting attack injector.")
            break
        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    main()
