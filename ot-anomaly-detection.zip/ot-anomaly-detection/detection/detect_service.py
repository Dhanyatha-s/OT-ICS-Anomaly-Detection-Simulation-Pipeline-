"""
detect_service.py
=================
WHAT THIS IS:
  The live detection engine. This runs continuously in the background,
  scoring every new sensor reading with both trained ML models
  and writing the anomaly score back into Elasticsearch.

WHAT IT DOES:
  Every 10 seconds:
  1. Queries Elasticsearch for new readings from the last 30 seconds
  2. Runs them through Isolation Forest → gets anomaly score
  3. Runs last 10 readings through LSTM Autoencoder → gets reconstruction error
  4. Combines both scores into a final "anomaly_score" (0.0 – 1.0)
  5. Updates the Elasticsearch documents with the scores
  6. Prints colored alerts to console when anomalies are detected

HOW IT LINKS TO EVERYTHING ELSE:
  Elasticsearch "ot-sensors" → [THIS SCRIPT] → Updates same documents
                                                      ↓
                                               Kibana reads updated scores
                                               and shows alerts on dashboard

HOW TO RUN:
  python detect_service.py
  (Run this AFTER training the models with train_model.py)
"""

import os
import json
import time
import numpy as np
import joblib
import logging
from datetime import datetime, timezone, timedelta
from elasticsearch import Elasticsearch, helpers
import tensorflow as tf

# ── Configuration ──────────────────────────────────────────────────────
ES_HOST       = "http://localhost:9200"
ES_INDEX      = "ot-sensors-*"
MODEL_DIR     = "./detection/models"
POLL_INTERVAL = 10       # Check for new data every 10 seconds
WINDOW_SECS   = 30       # Look back 30 seconds for new readings
SEQUENCE_LEN  = 10       # LSTM sequence length (must match training)
FEATURE_COLS  = ["temperature", "pressure", "flow_rate", "valve_numeric", "vibration"]

# Anomaly alert threshold (0.0 = definitely normal, 1.0 = definitely anomaly)
ALERT_THRESHOLD = 0.6

# ── Logging setup ──────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger(__name__)


# ── Model loader ───────────────────────────────────────────────────────

class AnomalyDetector:
    """
    Loads trained models and provides a unified scoring interface.
    """

    def __init__(self):
        self.if_model   = None
        self.lstm_model = None
        self.scaler     = None
        self.lstm_threshold = 0.01
        self.recent_buffer  = []    # Sliding window for LSTM sequences

    def load_models(self):
        """Load all saved model files from disk."""
        scaler_path    = os.path.join(MODEL_DIR, "scaler.joblib")
        if_path        = os.path.join(MODEL_DIR, "isolation_forest.joblib")
        lstm_path      = os.path.join(MODEL_DIR, "lstm_autoencoder.keras")
        threshold_path = os.path.join(MODEL_DIR, "lstm_threshold.json")

        # Scaler (required)
        if not os.path.exists(scaler_path):
            raise FileNotFoundError(f"Scaler not found at {scaler_path}\n"
                                    "Run train_model.py first!")
        self.scaler = joblib.load(scaler_path)
        log.info("✅ Scaler loaded")

        # Isolation Forest (required)
        if not os.path.exists(if_path):
            raise FileNotFoundError(f"Isolation Forest not found at {if_path}\n"
                                    "Run train_model.py first!")
        self.if_model = joblib.load(if_path)
        log.info("✅ Isolation Forest loaded")

        # LSTM (optional — may not exist if not enough training data)
        if os.path.exists(lstm_path):
            self.lstm_model = tf.keras.models.load_model(lstm_path)
            log.info("✅ LSTM Autoencoder loaded")

            if os.path.exists(threshold_path):
                with open(threshold_path) as f:
                    self.lstm_threshold = json.load(f)["threshold"]
                log.info(f"✅ LSTM threshold: {self.lstm_threshold:.6f}")
        else:
            log.warning("⚠️  LSTM model not found — using Isolation Forest only")

    def score_isolation_forest(self, X_scaled):
        """
        Get anomaly probability from Isolation Forest.
        Returns a value between 0.0 (normal) and 1.0 (very anomalous).

        decision_function returns negative scores for anomalies.
        We normalize to 0-1 range.
        """
        raw_scores = self.if_model.decision_function(X_scaled)
        # Invert and normalize: more negative = more anomalous = higher score
        # Typical range is roughly -0.5 to 0.5
        normalized = np.clip((-raw_scores + 0.5) / 1.0, 0.0, 1.0)
        return normalized

    def score_lstm(self, X_scaled):
        """
        Get anomaly probability from LSTM reconstruction error.
        Returns 0.0 if LSTM not available or not enough history.
        """
        if self.lstm_model is None:
            return np.zeros(len(X_scaled))

        # Add new readings to the sliding window buffer
        scores = np.zeros(len(X_scaled))

        for i, row in enumerate(X_scaled):
            self.recent_buffer.append(row)
            # Keep only last SEQUENCE_LEN readings
            if len(self.recent_buffer) > SEQUENCE_LEN:
                self.recent_buffer.pop(0)

            # Only score when we have a full sequence
            if len(self.recent_buffer) == SEQUENCE_LEN:
                seq = np.array(self.recent_buffer)[np.newaxis, :, :]  # (1, seq_len, features)
                reconstruction = self.lstm_model.predict(seq, verbose=0)
                error = float(np.mean(np.power(seq - reconstruction, 2)))

                # Normalize: how many times above threshold?
                normalized = np.clip(error / (self.lstm_threshold * 2), 0.0, 1.0)
                scores[i] = normalized

        return scores

    def score_batch(self, readings):
        """
        Main scoring function. Takes list of sensor reading dicts.
        Returns list of (anomaly_score, is_anomaly, method) tuples.
        """
        if not readings:
            return []

        # Extract feature values
        X = np.array([[r.get(f, 0) for f in FEATURE_COLS] for r in readings])

        # Scale using same scaler as training
        X_scaled = self.scaler.transform(X)

        # Get scores from both models
        if_scores   = self.score_isolation_forest(X_scaled)
        lstm_scores = self.score_lstm(X_scaled)

        results = []
        for i in range(len(readings)):
            # Combine scores: weighted average
            if self.lstm_model and lstm_scores[i] > 0:
                # Both models available and LSTM has a sequence
                combined = 0.5 * if_scores[i] + 0.5 * lstm_scores[i]
                method = "IF+LSTM"
            else:
                # Only Isolation Forest
                combined = if_scores[i]
                method = "IF_only"

            is_anomaly = bool(combined >= ALERT_THRESHOLD)
            results.append({
                "anomaly_score":    round(float(combined), 4),
                "if_score":         round(float(if_scores[i]), 4),
                "lstm_score":       round(float(lstm_scores[i]), 4),
                "is_anomaly":       is_anomaly,
                "detection_method": method,
                "scored_at":        datetime.now(timezone.utc).isoformat()
            })

        return results


# ── Elasticsearch operations ───────────────────────────────────────────

def fetch_recent_unscored(es, since_seconds=30):
    """
    Fetch documents from the last N seconds that haven't been scored yet.
    We identify "unscored" as those where anomaly_score is still 0.0.
    """
    since = (datetime.now(timezone.utc) - timedelta(seconds=since_seconds)).isoformat()

    query = {
        "query": {
            "bool": {
                "must": [
                    {"range": {"@timestamp": {"gte": since}}},
                    {"term":  {"anomaly_score": 0.0}}   # Not yet scored
                ]
            }
        },
        "sort": [{"@timestamp": {"order": "asc"}}],
        "size": 100
    }

    try:
        response = es.search(index=ES_INDEX, body=query)
        return response["hits"]["hits"]
    except Exception as e:
        log.warning(f"ES query failed: {e}")
        return []


def update_documents(es, doc_ids_and_scores):
    """
    Bulk update documents in Elasticsearch with anomaly scores.
    Bulk update is much faster than updating one by one.
    """
    if not doc_ids_and_scores:
        return

    # Build bulk update actions
    actions = []
    for doc_id, index_name, scores in doc_ids_and_scores:
        actions.append({
            "_op_type": "update",
            "_index":   index_name,
            "_id":      doc_id,
            "doc":      scores
        })

    try:
        helpers.bulk(es, actions, raise_on_error=False)
    except Exception as e:
        log.error(f"Bulk update failed: {e}")


def print_alert(reading, score_result):
    """Print colored console alert when anomaly detected."""
    score = score_result["anomaly_score"]
    if score >= 0.8:
        level = "🔴 CRITICAL"
    elif score >= 0.6:
        level = "🟠 HIGH"
    elif score >= 0.4:
        level = "🟡 MEDIUM"
    else:
        return  # Don't print low-score entries

    print(f"\n{'='*55}")
    print(f"  {level} ANOMALY DETECTED  (score: {score:.3f})")
    print(f"  Method: {score_result['detection_method']}")
    print(f"  Temp:      {reading.get('temperature', '?')}°C")
    print(f"  Pressure:  {reading.get('pressure', '?')} PSI")
    print(f"  Flow:      {reading.get('flow_rate', '?')} L/min")
    print(f"  Valve:     {reading.get('valve_label', '?')}")
    print(f"  Vibration: {reading.get('vibration', '?')} mm/s")
    print(f"{'='*55}\n")


# ── Main detection loop ────────────────────────────────────────────────

def main():
    print("=" * 60)
    print("OT Anomaly Detection Service — Live Scoring")
    print(f"Checking for new readings every {POLL_INTERVAL}s")
    print(f"Alert threshold: {ALERT_THRESHOLD}")
    print("=" * 60)

    # Load models
    detector = AnomalyDetector()
    try:
        detector.load_models()
    except FileNotFoundError as e:
        print(f"\n[ERROR] {e}")
        return

    # Connect to Elasticsearch
    log.info(f"Connecting to Elasticsearch at {ES_HOST}...")
    es = Elasticsearch(ES_HOST)
    if not es.ping():
        print("[ERROR] Cannot connect to Elasticsearch. Is Docker running?")
        return
    log.info("✅ Connected to Elasticsearch")

    total_scored    = 0
    total_anomalies = 0

    print("\n[RUNNING] Detection service active. Press Ctrl+C to stop.\n")

    try:
        while True:
            # Fetch unscored documents from the last 30 seconds
            hits = fetch_recent_unscored(es, since_seconds=WINDOW_SECS)

            if hits:
                readings      = [h["_source"] for h in hits]
                doc_meta      = [(h["_id"], h["_index"]) for h in hits]
                score_results = detector.score_batch(readings)

                # Prepare bulk update
                updates = []
                for i, (doc_id, index_name) in enumerate(doc_meta):
                    sr = score_results[i]
                    updates.append((doc_id, index_name, sr))

                    # Print alerts for anomalies
                    if sr["is_anomaly"]:
                        print_alert(readings[i], sr)
                        total_anomalies += 1

                update_documents(es, updates)
                total_scored += len(hits)

                log.info(f"Scored {len(hits)} new readings | "
                         f"Anomalies this batch: {sum(1 for r in score_results if r['is_anomaly'])} | "
                         f"Total scored: {total_scored} | Total anomalies: {total_anomalies}")
            else:
                log.info(f"No new unscored readings in last {WINDOW_SECS}s")

            time.sleep(POLL_INTERVAL)

    except KeyboardInterrupt:
        print(f"\n[STOP] Detection service stopped.")
        print(f"       Total scored: {total_scored}")
        print(f"       Total anomalies detected: {total_anomalies}")


if __name__ == "__main__":
    main()
