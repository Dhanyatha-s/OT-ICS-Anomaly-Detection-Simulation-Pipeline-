"""
train_model.py
==============
WHAT THIS IS:
  The machine learning brain of the project.
  This script trains two anomaly detection models on your collected sensor data.

WHAT IT DOES:
  1. Pulls all stored sensor readings from Elasticsearch
  2. Cleans and normalizes the data
  3. Trains Model A: Isolation Forest (fast, good for point anomalies)
  4. Trains Model B: LSTM Autoencoder (slower, catches sequence/pattern anomalies)
  5. Saves both models to disk
  6. Logs all metrics and experiments to MLFlow

WHEN TO RUN IT:
  - After collecting at least 1-2 hours of normal data from the simulator
  - Run it again after collecting attack data to compare performance
  - Re-run whenever you want to retrain on newer data

HOW IT LINKS TO EVERYTHING ELSE:
  Elasticsearch "ot-sensors" → [THIS SCRIPT] → saved model files
                                                      ↓
                                               detect_service.py loads them

HOW TO RUN:
  pip install elasticsearch pandas scikit-learn tensorflow mlflow numpy joblib
  python train_model.py
"""

import os
import json
import numpy as np
import pandas as pd
import joblib
import mlflow
import mlflow.sklearn
import mlflow.keras
from datetime import datetime, timezone
from elasticsearch import Elasticsearch
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import tensorflow as tf
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import LSTM, Dense, RepeatVector, TimeDistributed, Input
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint

# ── Configuration ──────────────────────────────────────────────────────
ES_HOST      = "http://localhost:9200"
ES_INDEX     = "ot-sensors-*"         # Match all daily indices

MLFLOW_URI   = "http://localhost:5000"
EXPERIMENT   = "OT-Anomaly-Detection"

MODEL_DIR    = "./detection/models"   # Where to save trained models
os.makedirs(MODEL_DIR, exist_ok=True)

# These are the features the ML model looks at
# (must match field names in Elasticsearch documents)
FEATURE_COLS = ["temperature", "pressure", "flow_rate", "valve_numeric", "vibration"]

# LSTM looks at sequences of readings (sliding window)
SEQUENCE_LEN = 10   # Look at last 10 readings (20 seconds of data)


# ── Step 1: Pull data from Elasticsearch ───────────────────────────────

def fetch_data_from_elasticsearch():
    """
    Query all sensor documents from Elasticsearch.
    Returns a pandas DataFrame sorted by timestamp.
    """
    print("[DATA] Connecting to Elasticsearch...")
    es = Elasticsearch(ES_HOST)

    # Check connection
    if not es.ping():
        raise ConnectionError("Cannot connect to Elasticsearch. Is Docker running?")

    print(f"[DATA] Fetching documents from index: {ES_INDEX}")

    # Use scroll API for large datasets (handles >10,000 documents)
    docs = []
    query = {
        "query": {"match_all": {}},
        "sort":  [{"@timestamp": {"order": "asc"}}],
        "size":  1000
    }

    # Initial search
    response = es.search(index=ES_INDEX, body=query, scroll="2m")
    scroll_id = response["_scroll_id"]
    hits = response["hits"]["hits"]

    while hits:
        for hit in hits:
            source = hit["_source"]
            docs.append({
                "timestamp":    hit["_source"].get("@timestamp"),
                "temperature":  source.get("temperature", 0),
                "pressure":     source.get("pressure", 0),
                "flow_rate":    source.get("flow_rate", 0),
                "valve_numeric":source.get("valve_numeric", 1),
                "vibration":    source.get("vibration", 0),
                "rule_alert":   source.get("rule_based_alert", False)
            })
        # Fetch next batch
        response = es.scroll(scroll_id=scroll_id, scroll="2m")
        hits = response["hits"]["hits"]

    es.clear_scroll(scroll_id=scroll_id)

    df = pd.DataFrame(docs)
    print(f"[DATA] Loaded {len(df)} documents")

    if len(df) < 100:
        print("[WARN] Less than 100 records found!")
        print("       Run the simulator for at least 30 minutes before training.")

    return df


# ── Step 2: Preprocess ─────────────────────────────────────────────────

def preprocess(df):
    """
    Clean data and normalize features.
    Normalization is critical — ensures all features contribute equally.
    Without it, temperature (70-85) would dominate pressure (80-120).
    """
    print("[PREP] Preprocessing data...")

    # Drop rows with missing values
    df = df.dropna(subset=FEATURE_COLS)

    # Sort by time
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df = df.sort_values("timestamp").reset_index(drop=True)

    # Extract features
    X = df[FEATURE_COLS].values.astype(float)

    # Fit scaler on the data
    # StandardScaler: transforms each feature to mean=0, std=1
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    print(f"[PREP] Feature matrix shape: {X_scaled.shape}")
    print(f"[PREP] Features: {FEATURE_COLS}")

    # Save scaler — detect_service.py needs the SAME scaler at inference time
    scaler_path = os.path.join(MODEL_DIR, "scaler.joblib")
    joblib.dump(scaler, scaler_path)
    print(f"[PREP] Scaler saved to {scaler_path}")

    return X_scaled, df


# ── Step 3A: Train Isolation Forest ───────────────────────────────────

def train_isolation_forest(X_scaled, run_id_prefix=""):
    """
    Isolation Forest — unsupervised anomaly detection.

    HOW IT WORKS:
      It randomly picks a feature and randomly picks a split value.
      Anomalies (outliers) are isolated with FEWER splits than normal points.
      contamination=0.05 means "expect ~5% of data to be anomalous."

    GOOD FOR: Point anomalies (single readings that are way off normal)
    """
    print("\n[IF] Training Isolation Forest...")

    with mlflow.start_run(run_name=f"IsolationForest_{run_id_prefix}"):
        # Log parameters to MLFlow
        params = {
            "n_estimators":  200,
            "contamination": 0.05,
            "max_features":  len(FEATURE_COLS),
            "random_state":  42
        }
        mlflow.log_params(params)
        mlflow.log_param("features", str(FEATURE_COLS))
        mlflow.log_param("n_samples", len(X_scaled))

        # Train the model
        model = IsolationForest(**params)
        model.fit(X_scaled)

        # Get anomaly scores for all training data
        # -1 = anomaly, 1 = normal (sklearn convention)
        predictions = model.predict(X_scaled)

        # Convert to 0/1 for readability
        anomaly_labels = (predictions == -1).astype(int)
        n_anomalies = anomaly_labels.sum()
        anomaly_rate = n_anomalies / len(X_scaled)

        print(f"[IF] Detected {n_anomalies} anomalies ({anomaly_rate:.1%} of data)")

        # Log metrics
        mlflow.log_metric("anomaly_count", int(n_anomalies))
        mlflow.log_metric("anomaly_rate", float(anomaly_rate))

        # Save model
        model_path = os.path.join(MODEL_DIR, "isolation_forest.joblib")
        joblib.dump(model, model_path)
        mlflow.sklearn.log_model(model, "isolation_forest")

        print(f"[IF] ✅ Model saved to {model_path}")
        mlflow.log_metric("training_complete", 1)

    return model


# ── Step 3B: Train LSTM Autoencoder ───────────────────────────────────

def create_sequences(X, seq_len):
    """
    Convert flat data into sequences for LSTM.
    LSTM needs to see time windows: [t-9, t-8, ..., t-0]
    Shape: (n_samples, seq_len, n_features)
    """
    sequences = []
    for i in range(len(X) - seq_len + 1):
        sequences.append(X[i:i + seq_len])
    return np.array(sequences)


def build_lstm_autoencoder(seq_len, n_features):
    """
    LSTM Autoencoder architecture.

    HOW IT WORKS:
      Encoder compresses the sequence into a small representation.
      Decoder tries to reconstruct the original sequence.
      If reconstruction error is HIGH → the pattern was unusual → ANOMALY.
      Normal data the model has seen before → low reconstruction error.

    GOOD FOR: Sequential/pattern anomalies (sustained unusual behavior over time)
    """
    inputs = Input(shape=(seq_len, n_features))

    # ENCODER — compress the sequence
    encoded = LSTM(64, activation='relu', return_sequences=False)(inputs)

    # BOTTLE NECK — compact representation
    bottleneck = Dense(16, activation='relu')(encoded)

    # DECODER — expand back to original
    decoded = RepeatVector(seq_len)(bottleneck)
    decoded = LSTM(64, activation='relu', return_sequences=True)(decoded)
    outputs = TimeDistributed(Dense(n_features))(decoded)

    model = Model(inputs, outputs, name="LSTM_Autoencoder")
    model.compile(optimizer='adam', loss='mse')
    return model


def train_lstm_autoencoder(X_scaled, run_id_prefix=""):
    """Train the LSTM Autoencoder on normal data."""
    print("\n[LSTM] Training LSTM Autoencoder...")
    print(f"[LSTM] Creating sequences of length {SEQUENCE_LEN}...")

    sequences = create_sequences(X_scaled, SEQUENCE_LEN)
    print(f"[LSTM] Sequence shape: {sequences.shape}")

    if len(sequences) < 50:
        print("[LSTM] Not enough data for LSTM training. Need 50+ sequences.")
        print("       Collect more data and retrain. Skipping LSTM for now.")
        return None

    # Train/validation split (90% train, 10% val)
    split = int(0.9 * len(sequences))
    X_train, X_val = sequences[:split], sequences[split:]

    with mlflow.start_run(run_name=f"LSTM_Autoencoder_{run_id_prefix}"):
        params = {
            "sequence_len":   SEQUENCE_LEN,
            "n_features":     len(FEATURE_COLS),
            "encoder_units":  64,
            "bottleneck_dim": 16,
            "epochs":         50,
            "batch_size":     32
        }
        mlflow.log_params(params)

        model = build_lstm_autoencoder(SEQUENCE_LEN, len(FEATURE_COLS))
        model.summary()

        # Callbacks: stop early if validation loss stops improving
        callbacks = [
            EarlyStopping(patience=5, restore_best_weights=True, monitor='val_loss'),
            ModelCheckpoint(
                filepath=os.path.join(MODEL_DIR, "lstm_autoencoder_best.keras"),
                save_best_only=True, monitor='val_loss'
            )
        ]

        history = model.fit(
            X_train, X_train,           # Autoencoder: input = target
            validation_data=(X_val, X_val),
            epochs=params["epochs"],
            batch_size=params["batch_size"],
            callbacks=callbacks,
            verbose=1
        )

        # Calculate reconstruction error threshold
        # Anomaly threshold = mean error + 3 standard deviations on training data
        train_pred = model.predict(X_train)
        train_errors = np.mean(np.power(X_train - train_pred, 2), axis=(1, 2))
        threshold = float(np.mean(train_errors) + 3 * np.std(train_errors))

        print(f"\n[LSTM] Reconstruction error threshold: {threshold:.6f}")
        print("[LSTM] Readings with error > threshold will be flagged as anomalies")

        # Log metrics and threshold
        mlflow.log_metric("final_val_loss", float(min(history.history['val_loss'])))
        mlflow.log_metric("anomaly_threshold", threshold)
        mlflow.log_metric("training_epochs_run", len(history.history['loss']))

        # Save threshold alongside model (detect_service.py needs it)
        threshold_path = os.path.join(MODEL_DIR, "lstm_threshold.json")
        with open(threshold_path, "w") as f:
            json.dump({"threshold": threshold}, f)

        # Save final model
        model_path = os.path.join(MODEL_DIR, "lstm_autoencoder.keras")
        model.save(model_path)
        print(f"[LSTM] ✅ Model saved to {model_path}")

    return model


# ── Main ───────────────────────────────────────────────────────────────

def main():
    print("=" * 60)
    print("OT Anomaly Detection — Model Training")
    print(f"MLFlow Experiment: {EXPERIMENT}")
    print("=" * 60)

    # Set up MLFlow
    mlflow.set_tracking_uri(MLFLOW_URI)
    mlflow.set_experiment(EXPERIMENT)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M")

    # Step 1: Load data
    df = fetch_data_from_elasticsearch()

    if len(df) == 0:
        print("[ERROR] No data found in Elasticsearch!")
        print("        Make sure the simulator and Kafka producer are running.")
        return

    # Step 2: Preprocess
    X_scaled, df_clean = preprocess(df)

    # Step 3: Train both models
    if_model   = train_isolation_forest(X_scaled, run_id_prefix=timestamp)
    lstm_model = train_lstm_autoencoder(X_scaled, run_id_prefix=timestamp)

    print("\n" + "=" * 60)
    print("✅ TRAINING COMPLETE")
    print(f"   Models saved in: {MODEL_DIR}/")
    print("   - isolation_forest.joblib")
    print("   - lstm_autoencoder.keras")
    print("   - scaler.joblib")
    print("   - lstm_threshold.json")
    print("\n   Next step: Run detect_service.py to start live detection!")
    print(f"   View experiments at: {MLFLOW_URI}")
    print("=" * 60)


if __name__ == "__main__":
    main()
