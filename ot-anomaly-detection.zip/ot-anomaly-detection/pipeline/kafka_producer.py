"""
kafka_producer.py
=================
WHAT THIS IS:
  The bridge between your OT device (modbus_server.py) and Kafka.
  It reads sensor data from the Modbus server every 2 seconds
  and publishes it as JSON messages into a Kafka topic.

WHAT IT DOES:
  1. Connects to the Modbus TCP server (your fake OT device)
  2. Reads all 5 sensor register values
  3. Converts raw integer values back to real units (÷100 etc.)
  4. Packages everything as a JSON message with a timestamp
  5. Publishes to Kafka topic: "ot-telemetry"

HOW IT LINKS TO EVERYTHING ELSE:
  modbus_server.py  →  THIS SCRIPT  →  Kafka "ot-telemetry" topic
                                            ↓
                                        Logstash reads it
                                            ↓
                                        Elasticsearch stores it
                                            ↓
                                        Kibana shows it

HOW TO RUN:
  pip install pymodbus kafka-python
  python kafka_producer.py

  (Make sure modbus_server.py is running first)
  (Make sure Docker is running with: docker-compose up -d)
"""

import json
import time
from datetime import datetime, timezone
from pymodbus.client import ModbusTcpClient
from kafka import KafkaProducer
from kafka.errors import NoBrokersAvailable

# ── Configuration ──────────────────────────────────────────────────────
MODBUS_HOST = "localhost"
MODBUS_PORT = 5020

KAFKA_BROKER = "localhost:9092"       # Where Kafka is running (Docker exposes this)
KAFKA_TOPIC  = "ot-telemetry"         # The "channel" messages go into

POLL_INTERVAL = 2                     # Read sensor every 2 seconds

# Register addresses (must match modbus_server.py)
REG_TEMPERATURE  = 0
REG_PRESSURE     = 1
REG_FLOW_RATE    = 2
REG_VALVE_STATUS = 3
REG_VIBRATION    = 4


def connect_kafka(retries=10, delay=5):
    """
    Try to connect to Kafka with retries.
    Kafka takes ~30 seconds to start inside Docker,
    so we keep trying until it's ready.
    """
    for attempt in range(1, retries + 1):
        try:
            print(f"[KAFKA] Connecting to broker at {KAFKA_BROKER} (attempt {attempt}/{retries})...")
            producer = KafkaProducer(
                bootstrap_servers=KAFKA_BROKER,
                value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                # Ensures messages are delivered reliably
                acks='all',
                retries=3
            )
            print(f"[KAFKA] ✅ Connected successfully!")
            return producer
        except NoBrokersAvailable:
            print(f"[KAFKA] Not ready yet. Waiting {delay}s...")
            time.sleep(delay)
    raise RuntimeError("Could not connect to Kafka after multiple attempts. Is Docker running?")


def connect_modbus(retries=5, delay=3):
    """Connect to the Modbus TCP server (modbus_server.py)."""
    for attempt in range(1, retries + 1):
        try:
            print(f"[MODBUS] Connecting to {MODBUS_HOST}:{MODBUS_PORT} (attempt {attempt}/{retries})...")
            client = ModbusTcpClient(MODBUS_HOST, port=MODBUS_PORT)
            if client.connect():
                print(f"[MODBUS] ✅ Connected to OT device simulator!")
                return client
            else:
                raise ConnectionError("Connection returned False")
        except Exception as e:
            print(f"[MODBUS] Failed: {e}. Waiting {delay}s...")
            time.sleep(delay)
    raise RuntimeError("Could not connect to Modbus server. Is modbus_server.py running?")


def read_sensor_data(client):
    """
    Read all 5 registers from the Modbus server.
    Returns a clean dictionary with real-world units.
    Returns None if the read fails.
    """
    # Read 5 registers starting at address 0
    result = client.read_holding_registers(address=0, count=5, slave=1)

    if result.isError():
        print(f"[MODBUS] Read error: {result}")
        return None

    regs = result.registers  # List of 5 integer values

    # Convert scaled integers back to real units
    return {
        "timestamp":    datetime.now(timezone.utc).isoformat(),
        "device_id":    "PLC-001",              # Identifier for this OT device
        "location":     "Substation-A",          # Where this sensor is installed
        "temperature":  regs[REG_TEMPERATURE]  / 100.0,   # °C
        "pressure":     regs[REG_PRESSURE]     / 10.0,    # PSI
        "flow_rate":    regs[REG_FLOW_RATE]    / 10.0,    # L/min
        "valve_status": regs[REG_VALVE_STATUS],            # 0/1/2
        "vibration":    regs[REG_VIBRATION]    / 100.0,   # mm/s
        # Derived field: valve as readable string
        "valve_label":  {0: "CLOSED", 1: "OPEN", 2: "PARTIAL"}.get(
                            regs[REG_VALVE_STATUS], "UNKNOWN"),
        "protocol":     "Modbus-TCP",
        "schema_version": "1.0"
    }


def main():
    print("=" * 60)
    print("Kafka Producer — OT Telemetry")
    print(f"Reading from Modbus: {MODBUS_HOST}:{MODBUS_PORT}")
    print(f"Publishing to Kafka topic: {KAFKA_TOPIC}")
    print("=" * 60)

    # Connect to both services
    modbus_client = connect_modbus()
    kafka_producer = connect_kafka()

    message_count = 0

    try:
        while True:
            # Read sensor data from OT device
            data = read_sensor_data(modbus_client)

            if data:
                # Send to Kafka
                # key = device_id, so messages from same device go to same partition
                kafka_producer.send(
                    KAFKA_TOPIC,
                    key=data["device_id"].encode('utf-8'),
                    value=data
                )
                message_count += 1

                print(f"[MSG #{message_count}] → Kafka | "
                      f"Temp={data['temperature']:.1f}°C  "
                      f"Pressure={data['pressure']:.1f}PSI  "
                      f"Flow={data['flow_rate']:.1f}L/min  "
                      f"Valve={data['valve_label']}")

                # Flush every 10 messages to ensure delivery
                if message_count % 10 == 0:
                    kafka_producer.flush()
                    print(f"[KAFKA] Flushed {message_count} messages so far")
            else:
                print("[WARN] Failed to read sensor — retrying next cycle")
                # Try to reconnect to Modbus
                try:
                    modbus_client.close()
                    modbus_client = connect_modbus(retries=3)
                except Exception:
                    pass

            time.sleep(POLL_INTERVAL)

    except KeyboardInterrupt:
        print("\n[STOP] Shutting down producer...")
    finally:
        kafka_producer.flush()
        kafka_producer.close()
        modbus_client.close()
        print(f"[DONE] Sent {message_count} total messages to Kafka")


if __name__ == "__main__":
    main()
